import { defineStore } from 'pinia'
import { getSubjects, saveSubject, updateSubject, createSubject, deleteSubject, assignTeacher, removeAssignment } from '../services/api/subjects'

export const useSchoolAdminSubjectsStore = defineStore('school-admin-subjects', {
  state: () => ({
    subjects: [],
    loading: false,
  }),
  actions: {
    async fetchSubjects() {
      this.loading = true
      try {
        const data = await getSubjects()
        this.subjects = Array.isArray(data) ? data : []
      } catch (error) {
        this.subjects = []
        // Don't throw the error, just continue with empty subjects
        // The UI component will handle showing the error message
      } finally {
        this.loading = false
      }
    },
    async saveSubject(payload) {
      const record = await saveSubject(payload)
      const exists = this.subjects.some((item) => item.id === record.id)
      this.subjects = exists
        ? this.subjects.map((item) => (item.id === record.id ? record : item))
        : [record, ...this.subjects]
    },
    async updateSubject(id, payload) {
      const record = await updateSubject(id, payload)
      this.subjects = this.subjects.map((item) => (item.id === record.id ? record : item))
      return record
    },
    async createSubject(payload) {
      const record = await createSubject(payload)
      this.subjects = [record, ...this.subjects]
      return record
    },
    async deleteSubject(id) {
      await deleteSubject(id)
      this.subjects = this.subjects.filter((item) => item.id !== id)
    },
    async assignTeacher(subjectId, payload) {
      return await assignTeacher(subjectId, payload)
    },
    async removeAssignment(subjectId, assignmentId) {
      return await removeAssignment(subjectId, assignmentId)
    },
    async deleteAssignment(subjectId, assignmentId) {
      return await this.removeAssignment(subjectId, assignmentId)
    },
  },
})
